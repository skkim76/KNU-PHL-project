import numpy as np

class leaf:
        def __init__(self, leaf_params):
                self.y0 = leaf_params[0]
                self.a  = leaf_params[1]
                self.b  = leaf_params[2]
                self.c  = leaf_params[3]
                self.d  = leaf_params[4]

        def area(self, CW, LL):
                output = self.y0 + self.a*CW + self.b*LL + self.c*CW**2 + self.d*LL**2
                return output

        def run(self, growth_data):
                No = []
                leafarea = []
                A = 0
                for individuals in growth_data:
                        leafarea.append(self.area(individuals[0],individuals[1]))

                        A += 1
                        No.append(A)

                return leafarea, No
